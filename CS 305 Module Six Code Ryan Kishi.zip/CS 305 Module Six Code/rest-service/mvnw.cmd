@echo off
setlocal

REM Resolve the project base directory (folder containing this script)
set MAVEN_PROJECTBASEDIR=%~dp0
REM Trim trailing backslash for consistent property value
if "%MAVEN_PROJECTBASEDIR:~-1%"=="\" set MAVEN_PROJECTBASEDIR=%MAVEN_PROJECTBASEDIR:~0,-1%

REM Location of the Maven Wrapper jar
set MAVEN_WRAPPER_JAR=%MAVEN_PROJECTBASEDIR%\.mvn\wrapper\maven-wrapper.jar

if exist "%MAVEN_WRAPPER_JAR%" (
  REM Run the wrapper by specifying the main class directly to avoid "no main manifest attribute"
  REM Pass the multi-module project directory system property (required by newer Maven wrappers)
  java -cp "%MAVEN_WRAPPER_JAR%" -Dmaven.multiModuleProjectDirectory="%MAVEN_PROJECTBASEDIR%" org.apache.maven.wrapper.MavenWrapperMain %*
) else (
  echo The Maven Wrapper jar was not found at "%MAVEN_WRAPPER_JAR%".
  echo Ensure the file exists and try again.
  exit /b 1
)

endlocal
exit /b %ERRORLEVEL%

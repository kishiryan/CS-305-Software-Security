package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HashController {

	private static final String DATA = "Ryan Kishi | CS305module7";

	@GetMapping(path = "/hash", produces = MediaType.TEXT_PLAIN_VALUE)
	public String getHash() {
		String checksum = sha256Hex(DATA);
		return "Data: " + DATA + "\nSHA-256: " + checksum;
	}

	static String sha256Hex(String input) {
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));

			StringBuilder hex = new StringBuilder(hash.length * 2);
			for (byte b : hash) {
				hex.append(String.format("%02x", b));
			}
			return hex.toString();
		} catch (NoSuchAlgorithmException e) {
			// redundancy catch check
			throw new IllegalStateException("SHA-256 not available", e);
		}
	}
}
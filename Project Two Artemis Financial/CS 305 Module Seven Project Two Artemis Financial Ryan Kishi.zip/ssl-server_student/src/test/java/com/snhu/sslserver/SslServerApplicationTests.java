package com.snhu.sslserver;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class SslServerApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Test
	void contextLoads() {
		// verifies Spring context starts
	}

	@Test
	void hashEndpointReturnsDataAndSha256Hex() throws Exception {
		String body = mockMvc.perform(get("/hash"))
				.andExpect(status().isOk())
				.andReturn()
				.getResponse()
				.getContentAsString();

		assertThat(body).contains("Data:");
		assertThat(body).contains("SHA-256:");

		// Ensure the final checksum looks like a SHA-256 hex digest
		String[] lines = body.split("\\R");
		assertThat(lines).hasSizeGreaterThanOrEqualTo(2);

		String checksumLine = lines[1];
		assertThat(checksumLine).matches("SHA-256: [0-9a-f]{64}");
	}

}